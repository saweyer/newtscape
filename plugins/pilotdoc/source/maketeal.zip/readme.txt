Updated: 09 Jul 1999
MakeTeal Current Version: 1.7
Premise: TealDoc is a cool idea. How about something that would change HTML 
pages directly into TealDoc pages? 
Download MakeTeal
readme.txt
Syntax
Register Me!
Stuff I've done:
Future of MakeTeal (maybe):
Why I wrote this:
NOTES
KNOWN BUGS:
RELEASE HISTORY:
Links for the misplaced: 




Syntax: 
MakeTeal [-nbthasRQ] < text-file > [< pdb-file > [< title >]]
convert text files to .PDB format
-b option compresses/decompresses binary
-n builds the .pdb file without compression
-t builds the .pdb file without HTML conversion (default)
-h builds the .pdb file with HTML conversion (turns off APROIS)
-a option APROIS (turns off HTML conversion)

-i# Image level
     0 = show NOTHING 2 = show ALT text (default) 4 = show ALT text or filename
     6 = display LOWSRC image (if there) or ALT text (if the LOWSRC isn't there) 
{not active} or ALT text (if not)
     8 = Display SRC file{not active)
-p TEMPORARY SWITCH Pass the base file name through as a TealPaint name

-T Do not extract < TITLE > from html files

MakeTeal -d [-b] < pdb-file > [< text-file >]
decodes the PDB back into the txt file
-b option compresses/decompresses binary

The < pdb-file > and < title > are optional. If you don't include < pdb-file >, 
it makes it based on the input file name. When < title > is not used, it's 
either extracted from the HTML title if possible, or (if the -T switch is used) 
the original input file name (made into lowercase) is used.

 



Registration: 
Yep, I'm selling out. Actually, I just became unemployed, so I need money (funny 
how that works out!) Registration is volentary through PalmPilotGear HQ. Check 
http://www.pilotgear.com/ if that last link doesn't work.



Stuff I've done:
    Cleaner Code (Yea, it's on-going. Deal.) 
    Extraction of < Title > for TealDoc title. 
    Numerical lists actually using numbers 
    Allowed the switches to be "bunched." i.e. "-bhsR" instead of "-b -h -s -R". 
    But the non-bunched still works. 
    -s command line switch to optionally remove messages inserted in to the 
    output file, specifically "Image not available" 
    Changed the report switches (q and r) to upper case (Q and R). 
    Added indent to the lower levels of lists. 
    Made the output filename in the decompression optional. 
    Made the -s switch not add extra blank lines. 
    Tinkered with the < TITLE > to remove extra spaces and ALL <CR/LF> for the 
    auto-title. 
    If the report switch is on, it puts the date MakeTeal was compiled at the 
    end of the report and .PDB files. 
    Fix < !-- -- > to include (exclude?) internal HTML tags. 
    Made < MENU > and < DIR > work identically to < UL >. 
    < IMG> will now give you the ALT= SRC= LOWSRC= or DYNSRC= info. 
    The numbered lists now actually USE the starting levels! 
    Replaced the bullet on < LI > stuff with something more readable. 
    Changed &#123; codes for the characters on the Pilot that are not in HTML. 
    If you want to play with it, add 1000 to get the Pilot ASCII code. So Pilot 
    ASCII code for 49 (the number 9) is &1049; If you want to see them all, 
    check out samples.pdb a converted version of samples.html. 
    Added the -p and -i switched to do more with image information. Play with it 
    to learn what it will do!
        Changed the "IMAGE NOT AVAILABLE to show -which- image is not available. 
        
    Added the -T switch to turn off the extraction of the title from < TITLE > 
    tags. Use this with the auto-generation of external links. 
    Internal links (target and buttons) are now generated, as well as links to 
    local files (still testing this). You should use the -T switch to generate 
    any files below the "parent" to allow the link to even have a chance of of 
    being generated correctly. It will NOT get the files linked to. Yet. 
    Forced all external links to be lowercase when I found out TealDoc file 
    names are case sensitive, unlike HTML. The -T switch also forces them to be 
    lowercase. 
    Changed the autobookmark tag at the bottom from < || > to < > when I found 
    out it would not auto-scan for stuff || as a bookmark. 
    Added in the Roman Numerals to < OL > list items (both upper and lower case) 
    - maximum of mmmcmxcix (3999) and minimum of I (1) before switching back to 
    Arabic numbers. REASON FOR THE MAXIMUM/MINIMUM: There are no letters with 
    the BAR over them, and there is nothing less than one. 
    Got a "Pocket Fisherman�" from RonCo.�� 
    Added conversion for <DL><DT> and <DD> 
    Fixed a bug where people would put in a "naked" ampersand and much later 
    have a semi-colon. COULD Cause large sections of text to disapper. Sorry. 
    Corrected a ">" between <> problem. 
    Undid the forcing of links to show up, when they were external. 
    Limited the length of target bookmarks to 15 characters. 
    Added in status display for html to teal conversion. 
    Removed the 's' 'R' and 'Q' switches. 



Future of MakeTeal (maybe):
    Fix < !-- -- > so it CORRECTLY excludes what it should! 
    Download depth/links
        List of "Never Get" for sub levels. 
        Switch for "only download from this server" and "only in this DIRECTORY" 
        for the depth stuff. 
    Finish HTML Bookmarks/Anchors. 
    Optional "return link" - will be a command switch, and will default to OFF 
    for obvious reasons. 
    Ordered lists using ALL of their types. 
    Tables handled better, like AT ALL. 
    Frames. Probably as a link to another document or something. 
    All operations to take place in memory. 
    Allow break-up of overly large documents into sections. 
    Use file list and commands (.INI file) 
    HTTP file locations, for download files off the web directly. 
    Get pictures as well.
        90 degree swivel option for images. 
        Scale images to fit 
    Cookies. Chocolate chips, of course. 
    Check crc-32 or equivalent to find if HTML or pictures have been modified. 
    Nice W95/W98/W2K front end but retain command line usage at all times. 
    Allow documents to have preset catagories. NOTE: AproisDoc didn't handle bad 
    catagories too well the last time I checked, so I won't allow it for 
    anything other than TealDoc, and maybe QED. 
    Download specific files only on specified date/day of week/etc. 
    Automatic timed/scheduled downloads. 
    See if anyone actually reads this darn thing. 
    Pilot-side program to make sure catgories on TealDoc, AproisDoc, SmartDoc 
    and others all have the same categories, and all doc files are in one of 
    those categoires. 



Why I wrote this:
Not that anyone cares, but the reason I put this together was because NONE (not 
a single one) of the other so-called HTML conversion programs seemed to handle 
the ampersand codes. I got tired of not being able to read the weather report 
without seeing "&#176;" instead of "�". Then there was the line of dashes that 
they used to replace the < HR > (Horizontal Rule) that ALWAYS wrapped the 
screen...
Annoy a programmer enough, and he'll write something he likes better.



NOTES:
    Registration is voluntary at point, and is available ONLY through PilotGear. 
    
        People that register the software get bug fixes faster, and get the 
        newer versions by E-Mail. 
    This is provided AS IS. If ANYTHING goes wrong, don't try to hold me 
    responsible! 
    There is NO real difference in the registered version. If they try to charge 
    you for something called MakeTeal that's not virtually identical to this, 
    it's not mine or you are being riped off! 
    If there ever IS a registered only version, I'll change the name. 
    No, I'm NOT going to do a Mac/Unix/Timex Sinclair version!
        "Someone" made an OS/2 conversion of ver 1.1 - as soon as he gives me an 
        address, I'll post it here. 
        "Someone" was given the code for ver 1.3 (sorry, grabbed the wrong 
        version!) to port to the Mac. After he gets set up, and as soon as he 
        gives me an address, I'll post it here. And give him a later version of 
        the HTML conversion code if he wants it. 
    If you want to make suggestions, feel free. I'd like to know what you want 
    that's NOT in the "To Do" list. 
    Bug reports (real ones) with REPODUCTION PATHS (i.e. "How'd you do that?") 
    come before suggestions. 
    Since it's going to become a full W95/98/NT program similar to MakeDocW, 
    I'll be using the Windows API stuff and have decided NOT to release the 
    source code to the general public. The source code for unixdoc.cpp is 
    available here. 



KNOWN BUGS:
    If the TealDoc file you try to create would be over a million bytes (yikes!) 
    the program will die in a nasty way. Deal with it. I'll fix it AND optimize 
    the memory stuff later. 
    There are a LOT of HTML tags that are not dealt with yet, but will be. There 
    are a lot of HTML tags that never will be dealt with. Bummer. 
    I cannot pass the TealDoc < LINK > tag through like I do all the other 
    TealDoc tags, beacause there is already an HTML < LINK > tag.
        Yes, that means if you put any of the other TealDoc tags in an HTML 
        document, or reconvert an already converted document, it -should- (in 
        theory) not hurt anything, except (as I said) for any < LINK > tags. 
    < OL > items in Roman notation above mmmcmxcix (3999) and below I (1) switch 
    to Arabic notation. There are no characters with a BAR over them, and no 
    ZERO on Roman numbers. That means 4000 displays as 4000. Not surprisingly 
    Internet Explorer does not deal with them either... 
    Bookmarks that are longer than 15 characters are truncated. As yet, I 
    haven't made that section "smart" 



RELEASE HISTORY:
Version 1.7 - 9 Jul 1999
    Corrected a ">" between < > problem. 
    Undid the forcing of links to show up, when they were external and 
    nonsupported. 
    Limited the length of target tags (bookmarks) to 15 characters. 
    Added in status display for html to teal conversion. 
    Removed the 's' 'R' and 'Q' switches. 
Version 1.6 - 11 Jun 1999 (Only sent to registered users.)
    Put in a little basic conversion stuff for definition lists. < DL > < DT > 
    and < DD >. This was done because I was trying to convert a page of 
    Gilbert&Sulivan lyrics... 
    Fixed a bug where people would put in a "naked" ampersand and much later 
    have a semi-colon. Caused large sections of text to disapper. Sorry. 
Version 1.5a - 17 Oct 1998
    Forced all external links to be lowercase when I found out TealDoc file 
    names are case sensitive, unlike HTML. The -T switch also forces them to be 
    lowercase. 
    Changed the autobookmark tag at the bottom from < || > to < > when I found 
    out it would not auto-scan for stuff || as a bookmark. 
    Added in the Roman Numerals to < OL > list items (both upper and lower case) 
    - maximum of mmmcmxcix (3999) and minimum of I (1) before switching back to 
    Arabic numbers. REASON FOR THE LIMITS: There are no letters with the BAR 
    over them, and the Romans never figured out zero. 
Version 1.5 - 17 Sep 1998
    Internal links (target and buttons) are now generated. 
    Added the -T switch to turn off the extraction of the title from < TITLE > 
    tags. Use this with the auto-generation of external links. 
    Links to other documents (and internal links/bookmarks) are now generated. 
    In order for them to work, you can NOT change the TITLE of the target 
    document, generate it with -T instead, so MakeTeal doesn't to use the < 
    TITLE > HTML tag. EVENTUALLY I will make it to read the target document and 
    find out it's < TITLE > but not yet. Sorry. 
    < A NAME=bookmark > now generates a bookmark (for autobookmarking) and label 
    for the < LINK> stuff. I advise using TITLE= parameter in the .html code to 
    allow them to look better. If you have questions, bear in mind that the .pdb 
    version of this document gets generated from the .html version. 
    Replaced the bullet on < LI > stuff with something more readable. 
    Changed &#123; codes for the characters on the Pilot that are not in HTML. 
    If you want to play with it, add 1000 to the Pilot ASCII code. So Pilot 
    ASCII code for 49 (the number 9) is &1049; If you want to see them all, 
    check out samples.pdb, a converted form of samples.html. 
    Added the -p and -i switched to do more with image information. Play with it 
    to learn what it will do!
        Changed the "IMAGE NOT AVAILABLE to show -which- image is not available. 
        
Version 1.4 - 9 Sep 1998
    Made < MENU > and < DIR > work identically to < UL >. 
    < IMG > will now give you the ALT= SRC= LOWSRC= or DYNSRC= info.
        What it gives you is based on the -i switch. Play with it to understand 
        it. Real manual type info starts happening AFTER I start charging! 
    Added the -p switch that outputs an image's base filename in a < TEALPAINT > 
    tag. This is a TEMPORARY switch, and still needs work! 
    The numbered lists now actually USE the starting levels! 
    Fixed a nasty bug that might cause a crash. 
Version 1.3a - 1 Sep 1998
    Made the output filename in the decompression optional. 
    Made the -s switch not add extra blank lines. 
    Tinkered with the < TITLE > to remove extra spaces and ALL < CR/LF > for the 
    auto-title. 
    If the report switch is on, it puts the date MakeTeal was compiled at the 
    end of the report and .PDB files. 
Version 1.3 - Date misplaced.
    Fixed switched to Allow them to be "grouped" i.e. "-bhsR" instead of "-b -h 
    -s -R". The non-grouped style still works, as long as they are all the FIRST 
    set of parameters. 
    Added the -s command line switch to optionally remove messages inserted in 
    to the output file, specifically "Image not available" 
    Changed the report switches (q and r) to upper case (Q and R). 
    Added indent to the lower levels of lists. 
Version: 1.2 - Date lost.
    Default title will be pulled from < TITLE >...< /TITLE > 
    < LI > list items that are numbered will (basically) retain their numbers. 
    (Still needs some work.) The starting number and format are not yet 
    implemented. 
    Got rid of a report (-r) bug. I'm probably the only one that noticed it. 
    Cleaned code. Cleaned more code. 
Version: 1.1 - Date forgotten.
    Changed the < IMG > tag to become a text string stating "Image not 
    available" 
    Tinkered with carrage returns to make them act a bit more like HTML. 
    There'll still not right though. 
Version 1.0 - 27 July 1998
    Oxygen starved brain mistakenly causes inital release of the program. 
    Luckly, no one notices... 
-No Prior Versions available in any store. 
 



Links for the misplaced: 
    MakeTeal home page: http://www.io.com/~bryce/maketeal.html 
    TealDoc home page:http://www.tealpoint.com/software.htm#doc 
    QED - First large document editor for the PalmPilot: 
    http://www.visionary2000.com/qed/index.htm 
    QEX - Pilot/Win95 Document Exchange Utility: 
    http://www.visionary2000.com/qed/qex.htm 
Mail for the misplaced: bryce@io.com
TealDoc is a product of TealPoint Software. I use it, registered it, and wrote 
this because I think it's good product. 
Likewise QED (a product of Visionary200).
Purchase at PilotGear: http://www.viamall.com/pilotgear



Worship the comic 
 
Gotta Love Bruno! Or I'll tell Stanley on you! 
 
