A ModPlayer for your newton!

V2.0b1

- Works on MP2000/MP2100 and emate.
- Untested on MP130, but I just added a new button this version,
"8Bit".  If checked, it *might?* work on mp130.  I don't own one to test it.

*** If you own an MP2K or emate, leave the 8bit box UNCHECKED! (that means 16Bit!)


I know some of the effects are not working 100% correctly, but
it works great for a large number of mods.

Currently supports only 4 channel (protracker and others)

Mods can be found all over the internet.  Try searching in Yahoo for "Mod Music", and that'll get you started, or find a selection in package form (ready-to-go) at my web-site (see end of file)

To create a package containing a mod:

- make a project in the NTK.
- give its' application name anything as long as it has .MOD embedded somewhere in it.  EG.  GuitarSlinger.MOD:SIG
- Add a clView to the project.
- set the views' viewBounds to all 0's
- set the views' viewSetupDoneScript as below:

func()
begin
	// attempt to launch the player and tell it to play this file
	if isFrame(GetRoot().|modPlayer:RSM|) then
	begin
		if call kViewIsOpenFunc with (GetRoot().|modPlayer:RSM|) = nil then
			GetRoot().|modPlayer:RSM|:Open();
		GetRoot().|modPlayer:RSM|:AutoPlay(kAppSymbol, 'aMod);
	end else begin
		:Notify(kNotifyAlert, kAppSymbol, 
			"Can't play MOD file, ModPlayer Application not installed!");
	end;
	AddDeferredSend(self, 'Close, []);
end

If using WINDOWS NTK:
  add a slot to the clView called aMod, and put in it:
  LoadDataFile("mods/"&kAppName,'modFile);

else, if using MAC NTK:
  add a slot to the clView called aMod, and put in it:

  OpenResFile(home&kAppName); 
  a := GetResource("MODf", 0, 'modFile); 
  CloseResFile(); 
  a; 

  Now, move the MOD file into a resource. Using Resorcerer, Open a   
  _copy_ of the MOD, get info on the data fork, and change the resource 
  type to 'MODf', ID 0. Save the copy in the directory with the
  project. 

that's it -- good luck!


The ModPlayer looks for packages with .MOD somewhere in the kAppName (Application Name)
and then scans the slots of the root view for a binary object of class 'modFile.

You can spawn the modplayer and request it to play a song like this:

GetRoot().|ModPlayer:RSM|:AutoPlayWithCallback(theModBinaryObjectOrVBO,nil,nil);
- you can pass a view and symbol of a functionname in that view to be called when the song
completes if you want (in place of the nil's), such as base,'songDoneFunc where...
songDoneFunc(songState) // located in the base view of your app
begin
	if songState='songDone then
	begin
		// song just finished!
	end;
end;


- When the newton wakes up from an alarm, it will play the last selected song if possible, or else it'll play any random song it can find.  If still no luck (no mods installed), it will play a system beep
every five seconds until the app is closed.

Visit www.geocities.com/SiliconValley/Code/5100/
for updates and more documentation.
roger_milne@geocities.com
